import numpy as np

def BiDipeptide(selected_sequence):
    print('读取RNA文件...')

    sequence = str(selected_sequence)

    print('开始提取RNA特征...')

    AA = 'AUGC'
    M = len(sequence)
    F1 = np.zeros((4 * 4, M - 1))  # 记录每两个氨基酸在每个位置出现的次数
    F2 = np.zeros((4 * 4, M - 1))

    for k in range(M - 1):
        s = sequence[k]
        t = sequence[k + 1]
        i = AA.index(s)
        j = AA.index(t)
        F1[j + (i * 4), k] += 1

    F1 /= len(sequence)

    PPT = np.zeros(2 * (M - 1))

    for k in range(M - 1):
        s = sequence[k]
        t = sequence[k + 1]
        i = AA.index(s)
        j = AA.index(t)
        PPT[k] = F1[j + (i * 4), k]

    print('RNA特征提取完成...')

    return PPT


