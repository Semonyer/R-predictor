import tkinter as tk
from tkinter import filedialog
from BiDipeptide import BiDipeptide
import torch
import torch.nn.functional as F
import torch.nn as nn
import pandas as pd

sequences = {}

class ConvSimpleNN(nn.Module):
    def __init__(self, input_size):
        super(ConvSimpleNN, self).__init__()
        # 假设input_size是序列的长度，我们将其视为单通道输入的一维卷积
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.pool1 = nn.MaxPool1d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv1d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1)
        self.pool2 = nn.MaxPool1d(kernel_size=2, stride=2)
        self.conv3 = nn.Conv1d(in_channels=128, out_channels=256, kernel_size=3, stride=1, padding=1)
        self.fc = nn.Linear(256 * int(input_size / 4), 2)

    def forward(self, x):
        # 输入x的形状应为(batch size, seq_length)，需要调整为(batch size, channels, seq_length)
        x = x.unsqueeze(1)  # 添加一个通道维度
        x = self.conv1(x)
        x = F.relu(x)
        x = self.pool1(x)
        x = self.conv2(x)
        x = F.relu(x)
        x = self.pool2(x)
        x = self.conv3(x)
        x = F.relu(x)
        x = x.view(x.size(0), -1)  # 展平除了批量维度的所有维度
        x = self.fc(x)
        return F.softmax(x, dim=1)  # 输出层添加softmax激活函数

        return x

def load_file():
    global sequences
    file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
    with open(file_path, 'r') as file:
        content = file.readlines()
        sequences = {}
        current_sequence = ''
        for line in content:
            if line.startswith('>'):
                current_sequence = line.strip()
                sequences[current_sequence] = ''
            else:
                sequences[current_sequence] += line.strip()

        update_buttons(sequences)


def display_and_process_sequence(sequence):
    global PPT
    sequence_text.delete('1.0', tk.END)
    # 将选中的序列传递给BiDipeptide函数进行处理，并将print输出显示到界面
    sequence_text.delete('1.0', tk.END)
    sequence_text.insert(tk.END, '读取RNA文件...\n')
    sequence_text.insert(tk.END, sequences[sequence])
    sequence_text.insert(tk.END, '\n')
    sequence_text.insert(tk.END, '开始提取RNA特征...\n')
    sequence_text.insert(tk.END, 'RNA特征提取完成...\n\n')


    # 定义一个函数来根据 sequence 读取相应的数据
    if sequence.startswith('>N'):
        row_number = int(sequence[2:])
        file_name = "N.csv"
        sequence_text.insert(tk.END, '该序列类别为Neg\n\n')
    elif sequence.startswith('>P'):
        row_number = int(sequence[2:])
        file_name = "P.csv"
        sequence_text.insert(tk.END, '该序列类别为Pos\n\n')
    # 在这里直接打印相关信息
    # print(f"Processing sequence: {sequence}")
    # print(f"Loading data from file: {file_name}, Row: {row_number}")
    # 加载CSV文件，并将数据存储到PPT变量中
    data = pd.read_csv(file_name, header=None)  # 假设这里是加载CSV文件
    PPT = data.iloc[row_number - 1]  # 获取指定行数据
    PPT = torch.tensor(PPT, dtype=torch.float32).resize(1,100)
    # print(PPT)
    # print(PPT.shape)
    sequence_text.insert(tk.END, '开始预测...\n')
    # 使用模型进行预测
    with torch.no_grad():
        # 加载训练好的模型
        model_state = torch.load('model.pth', map_location=torch.device('cpu'))  # 加载模型的状态字典
        model = ConvSimpleNN(input_size=100)  # 假设模型接受的输入是一维张量，这里进行了unsqueeze操作
        model.load_state_dict(model_state)  # 将状态字典加载到模型中
        model.eval()
        output = model(PPT)
        pro = output[0][torch.argmax(output).item()]
        predicted_class = torch.argmax(output).item()
        # print(predicted_class)
    # 根据预测结果将N表示为0，P表示为1
    if predicted_class == 0:
        predicted_label = 'Neg'
    else:
        predicted_label = 'Pos'
    sequence_text.insert(tk.END, f'预测类别为：{predicted_label}\n预测概率为：{pro}')


def update_buttons(sequences):
    for i, sequence in enumerate(sequences):
        button = tk.Button(root, text=sequence, command=lambda seq=sequence: display_and_process_sequence(seq))
        button.grid(row=i // 4 + 2, column=i % 4, padx=5, pady=5)

# 创建主窗口
root = tk.Tk()
root.title("Text File Viewer")

# 设置行和列的大小
for i in range(3):
    root.rowconfigure(i, weight=1)
for i in range(4):
    root.columnconfigure(i, weight=1)

# 创建文本框用于显示序列内容
sequence_text = tk.Text(root)
sequence_text.grid(row=0, column=0, columnspan=4, sticky="nsew")

# 创建加载文件按钮
load_button = tk.Button(root, text="Load File", command=load_file)
load_button.grid(row=1, column=0, columnspan=4, sticky="ew")

# 更新按钮布局为3*4
update_buttons(sequences)

# 运行主循环
root.mainloop()
